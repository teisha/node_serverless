var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'laimasoftrs',
applicationName: 'my-first-app',
appUid: 'VKMHntLqX3Xvvm63JQ',
orgUid: 'nVjLbGCjVY81Lx16wj',
deploymentUid: 'fd73dcc3-b602-4ff1-8c4a-e0f666eb89cd',
serviceName: 'tutorial-express-application',
stageName: 'dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'tutorial-express-application-dev-app', timeout: 6}
try {
  const userHandler = require('./index.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
